import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Banner from '../components/Banner';
import ProductCard from '../components/ProductCard';
import './styles/main.css';

const HomePage = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await fetch('/api/products');
                const data = await response.json();
                setProducts(data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, []);

    return (
        <div>
            <Navbar />
            <Banner />
            <div className="product-container">
                {products.map(product => (
                    <ProductCard 
                        key={product._id} 
                        product={product} 
                    />
                ))}
            </div>
        </div>
    );
};

export default HomePage;