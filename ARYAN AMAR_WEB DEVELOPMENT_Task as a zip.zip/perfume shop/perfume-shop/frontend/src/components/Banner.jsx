import React from 'react';
import './Banner.css'; // Assuming you have a CSS file for styling

const Banner = () => {
    return (
        <div className="banner">
            <h1>Discover Your Signature Scent</h1>
            <p>Explore our latest collections and special offers!</p>
            <button className="explore-button">Explore Now</button>
        </div>
    );
};

export default Banner;