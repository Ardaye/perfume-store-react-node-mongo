import React from 'react';

const ShareButton = ({ url, title }) => {
    const handleShare = (platform) => {
        let shareUrl = '';
        const text = encodeURIComponent(title);
        
        switch (platform) {
            case 'facebook':
                shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${text}`;
                break;
            case 'twitter':
                shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${text}`;
                break;
            case 'linkedin':
                shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}&title=${text}`;
                break;
            default:
                break;
        }

        window.open(shareUrl, '_blank');
    };

    return (
        <div className="share-button">
            <button onClick={() => handleShare('facebook')}>Share on Facebook</button>
            <button onClick={() => handleShare('twitter')}>Share on Twitter</button>
            <button onClick={() => handleShare('linkedin')}>Share on LinkedIn</button>
        </div>
    );
};

export default ShareButton;