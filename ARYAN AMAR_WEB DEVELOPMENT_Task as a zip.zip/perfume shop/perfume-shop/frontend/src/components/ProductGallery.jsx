import React, { useEffect, useState } from 'react';
import ProductCard from './ProductCard';

const ProductGallery = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await fetch('/api/products'); // Adjust the API endpoint as necessary
                const data = await response.json();
                setProducts(data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, []);

    return (
        <div className="product-gallery">
            {products.length > 0 ? (
                products.map(product => (
                    <ProductCard 
                        key={product._id} 
                        id={product._id} 
                        name={product.name} 
                        description={product.description} 
                        price={product.price} 
                        image={product.image} 
                    />
                ))
            ) : (
                <p>No products available.</p>
            )}
        </div>
    );
};

export default ProductGallery;