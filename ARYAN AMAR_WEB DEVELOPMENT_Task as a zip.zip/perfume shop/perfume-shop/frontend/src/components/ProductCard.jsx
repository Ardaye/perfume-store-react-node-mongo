import React from 'react';
import { useHistory } from 'react-router-dom';

const ProductCard = ({ product }) => {
    const history = useHistory();

    const handleCardClick = () => {
        history.push(`/product/${product._id}`);
    };

    return (
        <div className="product-card" onClick={handleCardClick}>
            <img src={product.image} alt={product.name} className="product-image" />
            <h3 className="product-name">{product.name}</h3>
            <p className="product-description">{product.description}</p>
            <p className="product-price">${product.price.toFixed(2)}</p>
            <style jsx>{`
                .product-card {
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 16px;
                    text-align: center;
                    cursor: pointer;
                    transition: transform 0.2s;
                }
                .product-card:hover {
                    transform: scale(1.05);
                }
                .product-image {
                    width: 100%;
                    height: auto;
                    border-radius: 8px;
                }
                .product-name {
                    font-size: 1.5em;
                    margin: 10px 0;
                }
                .product-description {
                    color: #555;
                }
                .product-price {
                    font-weight: bold;
                    color: #333;
                }
            `}</style>
        </div>
    );
};

export default ProductCard;