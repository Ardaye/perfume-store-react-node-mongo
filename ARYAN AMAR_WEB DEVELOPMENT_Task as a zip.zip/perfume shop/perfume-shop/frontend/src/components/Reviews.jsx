import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Reviews = ({ productId }) => {
    const [reviews, setReviews] = useState([]);
    const [newReview, setNewReview] = useState('');
    const [rating, setRating] = useState(1);

    useEffect(() => {
        const fetchReviews = async () => {
            try {
                const response = await axios.get(`/api/reviews/${productId}`);
                setReviews(response.data);
            } catch (error) {
                console.error('Error fetching reviews:', error);
            }
        };

        fetchReviews();
    }, [productId]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post(`/api/reviews`, {
                productId,
                reviewText: newReview,
                rating,
            });
            setReviews([...reviews, response.data]);
            setNewReview('');
            setRating(1);
        } catch (error) {
            console.error('Error posting review:', error);
        }
    };

    return (
        <div className="reviews-section">
            <h2>Customer Reviews</h2>
            <div className="reviews-list">
                {reviews.map((review) => (
                    <div key={review._id} className="review-card">
                        <p><strong>Rating: {review.rating}</strong></p>
                        <p>{review.reviewText}</p>
                    </div>
                ))}
            </div>
            <form onSubmit={handleSubmit}>
                <textarea
                    value={newReview}
                    onChange={(e) => setNewReview(e.target.value)}
                    placeholder="Write your review here..."
                    required
                />
                <select value={rating} onChange={(e) => setRating(e.target.value)}>
                    <option value={1}>1 Star</option>
                    <option value={2}>2 Stars</option>
                    <option value={3}>3 Stars</option>
                    <option value={4}>4 Stars</option>
                    <option value={5}>5 Stars</option>
                </select>
                <button type="submit">Submit Review</button>
            </form>
        </div>
    );
};

export default Reviews;