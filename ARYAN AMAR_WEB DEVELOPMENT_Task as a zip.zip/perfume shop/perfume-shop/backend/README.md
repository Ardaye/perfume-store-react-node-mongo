# Perfume Shop Backend

## Overview
This is the backend for the Perfume Shop application, built using Node.js and Express. It serves as the API for the frontend application, providing endpoints for managing products and reviews.

## Getting Started

### Prerequisites
- Node.js (version 14 or higher)
- MongoDB (local or cloud instance)

### Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   cd perfume-shop/backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

### Configuration
- Create a `.env` file in the root of the backend directory and add your MongoDB connection string:
  ```
  MONGODB_URI=<your_mongodb_connection_string>
  ```

### Running the Application
To start the server, run:
```
npm start
```
The server will run on `http://localhost:5000`.

### API Endpoints
- **Products**
  - `GET /api/products` - Fetch all products
  - `GET /api/products/:id` - Fetch a single product by ID

- **Reviews**
  - `GET /api/reviews/:productId` - Fetch reviews for a specific product
  - `POST /api/reviews` - Add a new review for a product

## Folder Structure
- `src/`
  - `controllers/` - Contains the logic for handling requests.
  - `models/` - Contains the Mongoose models for products and reviews.
  - `routes/` - Contains the route definitions for the API.
  - `app.js` - Initializes the Express application and middleware.
  - `db.js` - Handles the MongoDB connection.

## License
This project is licensed under the MIT License. See the LICENSE file for details.