const Review = require('../models/review');

// Fetch all reviews for a specific product
exports.getReviews = async (req, res) => {
    try {
        const reviews = await Review.find({ productId: req.params.productId });
        res.status(200).json(reviews);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching reviews', error });
    }
};

// Post a new review for a specific product
exports.postReview = async (req, res) => {
    const { productId, reviewText, rating } = req.body;

    const newReview = new Review({
        productId,
        reviewText,
        rating,
    });

    try {
        const savedReview = await newReview.save();
        res.status(201).json(savedReview);
    } catch (error) {
        res.status(500).json({ message: 'Error posting review', error });
    }
};