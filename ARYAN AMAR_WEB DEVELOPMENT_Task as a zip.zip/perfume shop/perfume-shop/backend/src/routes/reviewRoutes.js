const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');

// Route to get reviews for a specific product
router.get('/:productId', reviewController.getReviews);

// Route to post a new review for a specific product
router.post('/:productId', reviewController.addReview);

module.exports = router;